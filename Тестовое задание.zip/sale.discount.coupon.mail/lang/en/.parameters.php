<?
$MESS["SBP_PARAMETERS_USE_DISCOUNT_ID"] = "Use existing deal";
$MESS["SBP_PARAMETERS_DISCOUNT_ID"] = "Shopping cart rule";
$MESS["SBP_PARAMETERS_COUPON_IS_LIMITED"] = "Limited-time offer";
$MESS["SBP_PARAMETERS_COUPON_LIMIT_VALUE"] = "Coupon will expire in (since created)";
$MESS["SBP_PARAMETERS_COUPON_LIMIT_TYPE"] = "Unit";
$MESS["SBP_PARAMETERS_COUPON_DAY_LIMIT_TYPE"] = "day(s)";
$MESS["SBP_PARAMETERS_COUPON_WEEK_LIMIT_TYPE"] = "week(s)";
$MESS["SBP_PARAMETERS_COUPON_MONTH_LIMIT_TYPE"] = "month(s)";
$MESS["SBP_NEED_REQUIRED_MODULES"] = "This component requires the e-Store, Information Blocks and Commercial Catalog modules.";
$MESS["SBP_GROUPS_DISCOUNT"] = "Discount";
$MESS["SBP_GROUPS_COUPON"] = "Coupon";
$MESS["SBP_GROUPS_REPL_SETT"] = "Parameters";
$MESS["SBP_PARAMETERS_DISCOUNT_VALUE"] = "Discount value";
$MESS["SBP_PARAMETERS_DISCOUNT_UNIT"] = "Discount type";
$MESS["SBP_PARAMETERS_DISCOUNT_UNIT_EACH"] = "For each product";
$MESS["SBP_PARAMETERS_DISCOUNT_UNIT_ALL"] = "For all products";
$MESS["SBP_PARAMETERS_COUPON_TYPE"] = "Coupon type";
$MESS["SBP_PARAMETERS_COUPON_TYPE_ORDER"] = "Single use";
$MESS["SBP_PARAMETERS_COUPON_TYPE_BASKET"] = "For single order item";
$MESS["SBP_PARAMETERS_REPL_SETT_DISCOUNT_XML_ID"] = "\"XML_ID\" discount rule field";
$MESS["SBP_PARAMETERS_REPL_SETT_COUPON_DESCRIPTION"] = "\"Description\" coupon field";
?>