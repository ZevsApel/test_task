<?
$MESS["CVP_CATALOG_MODULE_NOT_INSTALLED"] = "The Commercial Catalog module is not installed.";
$MESS["CVP_SALE_MODULE_NOT_INSTALLED"] = "The e-Store module is not installed.";
$MESS["CVP_DISCOUNT_NAME"] = "Generated when sending the e-mail message";
$MESS["CVP_NO_MODULES"] = "Required modules are missing";
?>