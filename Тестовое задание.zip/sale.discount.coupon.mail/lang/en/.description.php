<?
$MESS["CP_CATALOG_SERVICES_MAIN_SECTION"] = "Web store";
$MESS["CP_CATALOG_SERVICES_PARENT_SECTION"] = "Product information";
$MESS["SB_DEFAULT_TEMPLATE_NAME"] = "Generate product coupon for use in e-mail";
$MESS["SB_DEFAULT_TEMPLATE_DESCRIPTION"] = "Shows a generated discount coupon. This component is mainly for use in e-mail templates.";
?>