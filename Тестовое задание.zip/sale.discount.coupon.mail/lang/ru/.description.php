<?
$MESS["CP_CATALOG_SERVICES_MAIN_SECTION"] = "Магазин";
$MESS["CP_CATALOG_SERVICES_PARENT_SECTION"] = "Информация о товарах";
$MESS["SB_DEFAULT_TEMPLATE_NAME"] = "Генерация купона на товар для почты";
$MESS["SB_DEFAULT_TEMPLATE_DESCRIPTION"] = "Выводит сгенерированный купон на скидку для товаров. Предполагается использование в почтовых шаблонах.";
?>