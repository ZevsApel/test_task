<?
$MESS["SBP_NEED_REQUIRED_MODULES"] = "Для работы компонента нужны установленные модули магазина, инфоблоков, и каталога.";
$MESS["SBP_GROUPS_DISCOUNT"] = "Скидка";
$MESS["SBP_GROUPS_COUPON"] = "Купон";
$MESS["SBP_GROUPS_REPL_SETT"] = "Параметры";

$MESS["SBP_PARAMETERS_DISCOUNT_VALUE"] = "Значение скидки";
$MESS["SBP_PARAMETERS_DISCOUNT_UNIT"] = "Тип скидки";
$MESS["SBP_PARAMETERS_DISCOUNT_UNIT_EACH"] = "На каждый товар";
$MESS["SBP_PARAMETERS_DISCOUNT_UNIT_ALL"] = "На сумму товаров";

$MESS["SBP_PARAMETERS_USE_DISCOUNT_ID"] = "Использовать существующую скидку";
$MESS["SBP_PARAMETERS_DISCOUNT_ID"] = "Правило работы с корзиной";

$MESS["SBP_PARAMETERS_COUPON_TYPE"] = "Тип купона";
$MESS["SBP_PARAMETERS_COUPON_TYPE_ORDER"] = "На один заказ";
$MESS["SBP_PARAMETERS_COUPON_TYPE_BASKET"] = "На одну позицию заказа";

$MESS["SBP_PARAMETERS_COUPON_IS_LIMITED"] = "Ограничить срок действия";
$MESS["SBP_PARAMETERS_COUPON_LIMIT_VALUE"] = "Срок действия (отсчет от даты создания купона)";
$MESS["SBP_PARAMETERS_COUPON_LIMIT_TYPE"] = "Тип срока";
$MESS["SBP_PARAMETERS_COUPON_DAY_LIMIT_TYPE"] = "день";
$MESS["SBP_PARAMETERS_COUPON_WEEK_LIMIT_TYPE"] = "неделя";
$MESS["SBP_PARAMETERS_COUPON_MONTH_LIMIT_TYPE"] = "месяц";

$MESS["SBP_PARAMETERS_REPL_SETT_DISCOUNT_XML_ID"] = "Поле правила скидки \"XML_ID\"";
$MESS["SBP_PARAMETERS_REPL_SETT_COUPON_DESCRIPTION"] = "Поле купона \"Описание\"";

$MESS["SBP_PARAMETERS_REPL_SETT_COUPON_USER"] = "Владелец купона";

?>