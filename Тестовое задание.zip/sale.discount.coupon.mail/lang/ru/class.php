<?
$MESS["CVP_CATALOG_MODULE_NOT_INSTALLED"] = "Модуль Каталогов не установлен";
$MESS["CVP_SALE_MODULE_NOT_INSTALLED"] = "Модуль магазина не установлен";
$MESS["CVP_DISCOUNT_NAME"] = "Купон на скидку";
$MESS['CVP_NO_MODULES'] = "Отсутствуют необходимые модули";
?>