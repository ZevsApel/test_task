<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/header.php");
$APPLICATION->SetTitle("Скидка");
?>


<?

CModule::IncludeModule('sale');

global $USER;

$userID = $USER->GetID();
$userGroup 	= $USER->GetUserGroupArray();
$resCoupons = \Bitrix\Sale\Internals\DiscountCouponTable::getList([
    'order' => ['DATE_CREATE' => 'desc'], 
    'filter' => [
    // Выводим только с описанием и пользователь в группе доступных
    // Или купон конкретно данного пользователя
        'LOGIC' => 'OR',
        [
            'USER_ID' => $userID,
            'CouponGroup.GROUP_ID' => $userGroup,
            '!DESCRIPTION' => false,
            'ACTIVE' => 'Y'
        ]
    ],
    'select' => [
        'ID',
        'COUPON',
        'DESCRIPTION',
        'MAX_USE',
        'DISCOUNT_ID',
        'ACTIVE_TO',
        'USER_ID'
    ],
    // Проверяем может ли пользователь в данной группе пользоваться данным купоном
    'runtime' => [
        (new \Bitrix\Main\ORM\Fields\Relations\Reference(
            'CouponGroup', 
            \Bitrix\Sale\Internals\DiscountGroupTable::class,
            \Bitrix\Main\ORM\Query\Join::on('this.DISCOUNT_ID', 'ref.DISCOUNT_ID')))
        ->configureJoinType('inner')
    ]
]);
                
                
    $arCoupons = [];
                
                
    while($coupon = $resCoupons->fetch()){
        $arCoupons = $coupon;	
    }
?>


<form method="POST">
     <input name="myActionName" type="submit" value="Получить скидку" />
</form>

<form method="POST">
    <input type="text" name="coupon" placeholder="Проверить купон">
    <input type="submit" name="checkCoup" value="Проверить купон">
</form>

<?
        
if (isset($_POST['myActionName'])){

    $sale = mt_rand(1, 50);
    
    $perc = '<p class="first_disc">Ваша скидка: ' . $sale . '%</p>';
    
    echo $perc;
            
    global $USER;
    $user_id = $USER->GetID();
    
    if(count($arCoupons) > 0) { 
        echo '<style>.first_disc{display:none;}</style>';
        echo 'У Вас уже есть купон: ' . $arCoupons['COUPON'];
    } else {
        
        echo 'Получите купон: ';
        
       $APPLICATION->IncludeComponent(
            "bitrix:sale.discount.coupon.mail",
            "",
            Array(
                "DISCOUNT_VALUE" => $sale,
                "DISCOUNT_UNIT" => "Perc",
                "COUPON_TYPE" => "Order",
                "DISCOUNT_XML_ID" => "{#SENDER_CHAIN_CODE#}",
                "COUPON_DESCRIPTION" => "{#EMAIL_TO#}",
                "USER_ID" => $user_id,
            )
        );
    } 
    
     $today = new \Bitrix\Main\Type\DateTime;
        
    $delDisc = $arCoupons['ACTIVE_TO'];
                
    if (strcasecmp($today, $delDisc)) {
        \Bitrix\Sale\Internals\DiscountCouponTable::deleteByDiscount($arCoupons['DISCOUNT_ID']);
    }
}

if (isset($_POST['checkCoup'])){
            
    $couponInput = $_POST['coupon'];
            
    if($userID != $arCoupons['USER_ID']) {
        echo 'Купон Вам не принадлежит';
    } else {
        echo 'Купон еще действителен';
    }
}
?>

<style>
    input[name="myActionName"] {
        margin: 10px 0;
    }
</style>

<?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/footer.php");?>