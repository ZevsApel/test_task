<?
$sSectionName = "Скидка";
$arDirProperties = Array(

);
?>